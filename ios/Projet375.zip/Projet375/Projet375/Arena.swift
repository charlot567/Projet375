//
//  Arena.swift
//  Projet375
//
//  Created by Charles-Olivier Demers on 17-02-05.
//  Copyright © 2017 Factory26. All rights reserved.
//

import UIKit

class Arena {

    var id: Int!
    var name: String!
    var winner: User!
    var lat: Double!
    var long: Double!
    var nbQuestionReussi: Int!
    var point: Int!


}
