//
//  UserChart.swift
//  Projet375
//
//  Created by Charles-Olivier Demers on 17-02-05.
//  Copyright © 2017 Factory26. All rights reserved.
//

import UIKit

class UserChart {
    var playerId: String!
    var playerCompleteName: String!
    var urlImage: String!
    var point: Int!
    
    var profileImage: UIImage!
}
